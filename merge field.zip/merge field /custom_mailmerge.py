# docx introduction: https://www.toptal.com/xml/an-informal-introduction-to-docx

# lxml documentation: https://lxml.de/tutorial.html
# https://lxml.de/api/lxml.etree._ElementTree-class.html
# https://lxml.de/api/lxml.etree._Element-class.html
# https://lxml.de/tutorial.html#elementpath

from copy import deepcopy
from zipfile import ZIP_DEFLATED, ZipFile

from lxml import etree
from lxml.etree import Element

NAMESPACE_WORDPROCESSINGML = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'  # noqa
NAMESPACE_CONTENT_TYPE = 'http://schemas.openxmlformats.org/package/2006/content-types'  # noqa
NAMESPACE_OFFICE_WORD_2010 = 'http://schemas.microsoft.com/office/word/2010/wordml'

ELEMENT_PATH_RECURSIVE_MERGE_FIELD = f'.//{{{NAMESPACE_WORDPROCESSINGML}}}t[@is_merge_field="True"]'

CONTENT_TYPES_PARTS = (
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml',  # noqa
    'application/vnd.openxmlformats-officedocument.wordprocessingml.header+xml',  # noqa
    'application/vnd.openxmlformats-officedocument.wordprocessingml.footer+xml',  # noqa
)

OPEN_TAG = '«'
CLOSE_TAG = '»'

CHECKBOX_CHECKED_TEXT = '☒'
CHECKBOX_UNCHECKED_TEXT = '☐'

MERGE_FIELD_TYPE_TEXT = 'text'
MERGE_FIELD_TYPE_CHECKBOX = 'checkbox'


class MergeField:
    def __init__(self, file, is_remove_empty_table=False):
        self.zip: ZipFile = ZipFile(file)
        self.parts: dict = {}
        self.merge_field_name__elements: dict = {}
        self.merge_field_name_in_table__details: dict = {}
        self.merge_field_name__list_group_checkbox_details: dict = {}

        self.is_remove_empty_table: bool = is_remove_empty_table

        try:
            content_types = etree.parse(self.zip.open('[Content_Types].xml'))
            for file in content_types.findall(f'{{{NAMESPACE_CONTENT_TYPE}}}Override'):
                if file.attrib['ContentType'] in CONTENT_TYPES_PARTS:
                    filename = file.attrib['PartName'].split('/', 1)[1]  # remove first /
                    self.parts[filename] = etree.parse(self.zip.open(self.zip.getinfo(filename)))

            for part in self.parts.values():
                self.__parse_merge_fields(part=part)  # init data for merge_field_name__elements
                self.__parse_tables(part=part)  # init data for merge_field_name_in_table__details
                self.__parse_checkboxes_v3(part=part)  # init data for merge_field_name__list_group_checkbox_details
            print("ggggggggggggggggggggggggggg", self.merge_field_name__list_group_checkbox_details)
        except Exception as ex:
            self.zip.close()
            raise ex

    def __parse_merge_fields(self, part):
        is_found_merge_field = False
        is_first_element_contains_open_tag = False
        part_of_name_merge_fields = []
        part_of_merge_fields = []

        merge_fields = part.findall(f'.//{{{NAMESPACE_WORDPROCESSINGML}}}t')

        for merge_field in merge_fields:
            if OPEN_TAG not in merge_field.text and not is_found_merge_field:
                continue

            if OPEN_TAG in merge_field.text and not is_found_merge_field:
                is_found_merge_field = True
                is_first_element_contains_open_tag = True

                # can not found close tag in previous merge field
                if OPEN_TAG != CLOSE_TAG:
                    part_of_name_merge_fields = []
                    part_of_merge_fields = []

            part_of_name_merge_fields.append(merge_field.text)
            # add element between open and close tag to list need to delete
            part_of_merge_fields.append(merge_field)

            if is_first_element_contains_open_tag:
                if (OPEN_TAG != CLOSE_TAG and CLOSE_TAG not in merge_field.text) \
                        or (OPEN_TAG == CLOSE_TAG and merge_field.text.count(CLOSE_TAG) != 2):
                    is_first_element_contains_open_tag = False
                    continue

            if CLOSE_TAG in merge_field.text:
                # there are some text before OPEN_TAG -> add new element contains text before OPEN_TAG
                if not part_of_name_merge_fields[0].startswith(OPEN_TAG):
                    remainder, first_part_of_name_merge_field = part_of_name_merge_fields[0].split(OPEN_TAG)

                    part_of_name_merge_fields[0] = f'{OPEN_TAG}{first_part_of_name_merge_field}'

                    remainder_element = deepcopy(merge_field)
                    remainder_element.text = remainder
                    merge_field.addprevious(remainder_element)

                # there are some text after CLOSE_TAG -> add new element contains text after CLOSE_TAG
                if not part_of_name_merge_fields[-1].endswith(CLOSE_TAG):
                    last_part_of_name_merge_field, remainder = part_of_name_merge_fields[-1].split(CLOSE_TAG)

                    part_of_name_merge_fields[-1] = f'{last_part_of_name_merge_field}{CLOSE_TAG}'

                    remainder_element = deepcopy(merge_field)
                    remainder_element.text = remainder
                    merge_field.addnext(remainder_element)

                merge_field_name = ''.join(part_of_name_merge_fields)
                merge_field.text = merge_field_name

                # set new attribute named is_merge_field -> easy find this element by filter by #elementpath
                merge_field.set('is_merge_field', 'True')

                merge_field_name = merge_field_name[1:-1]

                # maybe there are some merge field with the same name -> add to list
                if merge_field_name not in self.merge_field_name__elements:
                    self.merge_field_name__elements[merge_field_name] = []
                self.merge_field_name__elements[merge_field_name].append(merge_field)

                # remove current merge field
                part_of_merge_fields.pop()

                # delete all element between open and close tag
                for element in part_of_merge_fields:
                    parent = element.getparent()
                    grand_parent = parent.getparent()
                    grand_parent.remove(parent)

                is_found_merge_field = False
                part_of_name_merge_fields = []
                part_of_merge_fields = []

    def __parse_tables(self, part):
        tables = part.findall(f'.//{{{NAMESPACE_WORDPROCESSINGML}}}tbl')
        for table in tables:
            for row in table:
                merge_fields = row.findall(ELEMENT_PATH_RECURSIVE_MERGE_FIELD)
                for merge_field in merge_fields:
                    self.merge_field_name_in_table__details[merge_field.text[1:-1]] = {
                        'table': table,
                        'row': row
                    }

    # def __parse_checkboxes_v2(self, part):
    #     paragraphs = part.findall(f'.//{{{NAMESPACE_WORDPROCESSINGML}}}p')
    #     for paragraph in paragraphs:
    #         match_first_field_checkbox = paragraph.findall(f'.//{{{NAMESPACE_OFFICE_WORD_2010}}}checkbox')
    #
    #         if match_first_field_checkbox:
    #             checkbox_infos = []
    #             checkbox_info = None
    #             is_found_checkbox = False
    #
    #             for element in paragraph.iter():
    #                 if element.tag == f'{{{NAMESPACE_WORDPROCESSINGML}}}sdtContent':
    #                     if not is_found_checkbox:
    #                         is_found_checkbox = True
    #                     else:
    #                         checkbox_infos.append(checkbox_info)
    #
    #                     checkbox_info = {
    #                         'checkbox_obj': element,
    #                         'part_values': []
    #                     }
    #
    #                 if is_found_checkbox and element.tag == f'{{{NAMESPACE_WORDPROCESSINGML}}}t':
    #                     if not element.get('is_merge_field'):
    #                         checkbox_info['part_values'].append(element.text)
    #
    #                     else:
    #                         checkbox_infos.append(checkbox_info)
    #                         # join part_values to one string
    #                         for checkbox_info in checkbox_infos:
    #                             if CHECKBOX_UNCHECKED in checkbox_info['part_values']:
    #                                 checkbox_info["part_values"].remove(CHECKBOX_UNCHECKED)
    #                             checkbox_info['value'] = ''.join(checkbox_info['part_values']).strip()
    #                             del checkbox_info['part_values']
    #
    #                         merge_field_name = element.text[1:-1]
    #                         if merge_field_name not in self.merge_field_name__list_group_checkbox_details:
    #                             self.merge_field_name__list_group_checkbox_details[merge_field_name] = []
    #
    #                         # IMPORTANT: only append new group checkboxes by this merge field
    #                         # and do not delete in self.merge_field_name__elements to keep the order of fields
    #                         self.merge_field_name__list_group_checkbox_details[merge_field_name].append({
    #                             'checkbox_infos': checkbox_infos,
    #                             'values': [checkbox_info['value'] for checkbox_info in checkbox_infos],
    #                             'merge_field': element
    #                         })
    #                         # re-assign value for process new group of checkboxes (if exist)
    #                         # same way with before for element in cell.iter():
    #                         checkbox_infos = []
    #                         checkbox_info = None
    #                         is_found_checkbox = False

    def __parse_checkboxes_v3(self, part):
        # tree order finding checkbox in a tc:
        print("da vao")
        # tc -> p -> r -> fldChar -> ffData -> checkBox
        cells = part.findall(f'.//{{{NAMESPACE_WORDPROCESSINGML}}}tc')
        for cell in cells:
            first_matching_checkbox = cell.find(f'.//{{{NAMESPACE_OFFICE_WORD_2010}}}checkbox')
            if first_matching_checkbox is not None:
                checkbox_infos = []
                checkbox_info = None
                is_found_checkbox = False
                # iterate over all elements in the subtree in Preorder (Root, Left, Right)
                for element in cell.iter():

                    if element.tag == f'{{{NAMESPACE_OFFICE_WORD_2010}}}checkbox':
                        grantparent = element.getparent().getparent()
                        for child_element in grantparent.iter():
                            if child_element.tag == f'{{{NAMESPACE_WORDPROCESSINGML}}}sdtContent':
                                if not is_found_checkbox:
                                    is_found_checkbox = True
                                else:
                                    checkbox_infos.append(checkbox_info)

                                checkbox_info = {
                                    'checkbox_obj': child_element,
                                    'part_values': []
                                }
                            print("nnnnnnnnnnnnnn", checkbox_info)
                    if is_found_checkbox and element.tag == f'{{{NAMESPACE_WORDPROCESSINGML}}}t':
                        if not element.get('is_merge_field'):
                            checkbox_info['part_values'].append(element.text)

                        # found merge field which is the nearest with last checkbox
                        # -> group checkboxes together by this merge field
                        else:

                            # append last checkbox_info
                            checkbox_infos.append(checkbox_info)

                            # join part_values to one string
                            for checkbox_info in checkbox_infos:
                                if CHECKBOX_UNCHECKED_TEXT in checkbox_info['part_values']:
                                    checkbox_info["part_values"].remove(CHECKBOX_UNCHECKED_TEXT)
                                if CHECKBOX_UNCHECKED_TEXT in checkbox_info['part_values']:
                                    checkbox_info["part_values"].remove(CHECKBOX_CHECKED_TEXT)
                                checkbox_info['value'] = ''.join(checkbox_info['part_values']).strip()
                                del checkbox_info['part_values']
                            merge_field_name = element.text[1:-1]

                            if merge_field_name not in self.merge_field_name__list_group_checkbox_details:
                                self.merge_field_name__list_group_checkbox_details[merge_field_name] = []

                            # IMPORTANT: only append new group checkboxes by this merge field
                            # and do not delete in self.merge_field_name__elements to keep the order of fields
                            self.merge_field_name__list_group_checkbox_details[merge_field_name].append({
                                'checkbox_infos': checkbox_infos,
                                'values': [checkbox_info['value'] for checkbox_info in checkbox_infos],
                                'merge_field': element
                            })
                            # same way with before for element in cell.iter():
                            checkbox_infos = []
                            checkbox_info = None
                            is_found_checkbox = False

    def __parse_checkboxes(self, part):
        # tree order finding checkbox in a tc:
        # tc -> p -> r -> fldChar -> ffData -> checkBox

        cells = part.findall(f'.//{{{NAMESPACE_WORDPROCESSINGML}}}tc')
        for cell in cells:
            first_matching_checkbox = cell.find(f'.//{{{NAMESPACE_WORDPROCESSINGML}}}checkBox')
            if first_matching_checkbox is not None:
                checkbox_infos = []
                checkbox_info = None
                is_found_checkbox = False
                # iterate over all elements in the subtree in Preorder (Root, Left, Right)
                for element in cell.iter():
                    if element.tag == f'{{{NAMESPACE_WORDPROCESSINGML}}}checkBox':
                        if not is_found_checkbox:
                            is_found_checkbox = True
                        else:
                            checkbox_infos.append(checkbox_info)

                        checkbox_info = {
                            'checkbox_obj': element,
                            'part_values': []
                        }

                    if is_found_checkbox and element.tag == f'{{{NAMESPACE_WORDPROCESSINGML}}}t':
                        if not element.get('is_merge_field'):
                            checkbox_info['part_values'].append(element.text)

                        # found merge field which is the nearest with last checkbox
                        # -> group checkboxes together by this merge field
                        else:

                            # append last checkbox_info
                            checkbox_infos.append(checkbox_info)

                            # join part_values to one string
                            for checkbox_info in checkbox_infos:
                                checkbox_info['value'] = ''.join(checkbox_info['part_values']).strip()
                                del checkbox_info['part_values']
                            merge_field_name = element.text[1:-1]

                            if merge_field_name not in self.merge_field_name__list_group_checkbox_details:
                                self.merge_field_name__list_group_checkbox_details[merge_field_name] = []

                            # IMPORTANT: only append new group checkboxes by this merge field
                            # and do not delete in self.merge_field_name__elements to keep the order of fields
                            self.merge_field_name__list_group_checkbox_details[merge_field_name].append({
                                'checkbox_infos': checkbox_infos,
                                'values': [checkbox_info['value'] for checkbox_info in checkbox_infos],
                                'merge_field': element
                            })

                            # re-assign value for process new group of checkboxes (if exist)
                            # same way with before for element in cell.iter():
                            checkbox_infos = []
                            checkbox_info = None
                            is_found_checkbox = False

    @property
    def merge_fields(self):
        merge_field_name__infos = {}

        for merge_field_name in self.merge_field_name__elements.keys():
            merge_field_name__infos[merge_field_name] = {
                'type': MERGE_FIELD_TYPE_TEXT,
                'values': None
            }

        for merge_field_checkbox_name, group_checkbox_details in self.merge_field_name__list_group_checkbox_details.items():
            merge_field_name__infos[merge_field_checkbox_name] = {
                'type': MERGE_FIELD_TYPE_CHECKBOX,
                'values': []
            }
            for group_checkbox_detail in group_checkbox_details:
                for value in group_checkbox_detail['values']:
                    if value not in merge_field_name__infos[merge_field_checkbox_name]['values']:
                        merge_field_name__infos[merge_field_checkbox_name]['values'].append(value)

        return merge_field_name__infos

    def write(self, file):
        # clear attribute is_merge_field
        for part in self.parts.values():
            merge_fields = part.findall(ELEMENT_PATH_RECURSIVE_MERGE_FIELD)
            for merge_field in merge_fields:
                text = merge_field.text
                merge_field.clear()
                merge_field.text = text

        with ZipFile(file, 'w', ZIP_DEFLATED) as output:
            for zip_info in self.zip.filelist:
                filename = zip_info.filename
                if filename in self.parts:
                    xml = etree.tostring(self.parts[filename].getroot())
                    output.writestr(filename, xml)
                else:
                    output.writestr(filename, self.zip.read(zip_info))

    def merge(self, replacements: dict):
        for field_name, replacement in replacements.items():
            if isinstance(replacement, list):
                if field_name in self.merge_field_name__list_group_checkbox_details:
                    print("bbbbbbbbbbbbb", field_name)
                    self.__merge_checkbox_v3(field_name=field_name, values=replacement)
                else:
                    self.__merge_rows(anchor=field_name, rows=replacement)
            else:
                self.__merge_field(field_name=field_name, text=replacement)

    def __merge_rows(self, anchor, rows):
        if anchor not in self.merge_field_name__elements:
            return None

        table = self.merge_field_name_in_table__details[anchor]['table']
        row = self.merge_field_name_in_table__details[anchor]['row']

        if len(rows) > 0:
            for row_data in rows:
                new_row = deepcopy(row)
                table.append(new_row)

                merge_fields = new_row.findall(ELEMENT_PATH_RECURSIVE_MERGE_FIELD)
                for merge_field in merge_fields:
                    text = row_data.get(merge_field.text[1:-1])
                    if text:
                        self.__fill_merge_field(merge_field=merge_field, parent=merge_field.getparent(), text=text)

            table.remove(row)
        else:
            if self.is_remove_empty_table:
                parent = table.getparent()
                parent.remove(table)

    def __merge_field(self, field_name, text):
        for merge_field in self.merge_field_name__elements.get(field_name, []):
            parent = merge_field.getparent()

            # remove blank line
            if not text \
                    and merge_field.text[1:-1] not in self.merge_field_name_in_table__details \
                    and len(parent.getchildren()) == 2:

                grand_parent = parent.getparent()

                is_contain_num_format = False

                format_element = parent[0]  # pPr element
                for detail_format_element in format_element:
                    # if have tag bulleted or numbered list format then by pass
                    if 'numPr' in detail_format_element.tag:
                        is_contain_num_format = True
                        break

                if not is_contain_num_format:
                    great_grand_parent = grand_parent.getparent()
                    great_grand_parent.remove(grand_parent)

            else:
                self.__fill_merge_field(merge_field=merge_field, parent=parent, text=text)

    # def __merge_checkbox_v2(self, field_name, values):
    #     for group_checkbox_detail in self.merge_field_name__list_group_checkbox_details[field_name]:
    #         self.__fill_merge_field(
    #             merge_field=group_checkbox_detail['merge_field'],
    #             parent=group_checkbox_detail['merge_field'].getparent(),
    #             text=''
    #         )
    #
    #         # nếu value truyền lên ko có trong các value của checkbox thì bỏ qua
    #         if any([value not in group_checkbox_detail['values'] for value in values]):
    #             continue
    #
    #         for checkbox_info in group_checkbox_detail['checkbox_infos']:
    #             if checkbox_info['value'] in values:
    #                 for element in checkbox_info['checkbox_obj'].iter():
    #                     if element.tag == f'{{{NAMESPACE_WORDPROCESSINGML}}}t':
    #                         element.text = CHECKBOX_CHECKED

    def __merge_checkbox_v3(self, field_name, values):
        for group_checkbox_detail in self.merge_field_name__list_group_checkbox_details[field_name]:
            #print(self.merge_field_name__list_group_checkbox_details[field_name])
            print("group_checkbox_detail", group_checkbox_detail['merge_field'].tag)
            print("666666666666", group_checkbox_detail['merge_field'].getparent())
            print('a')
            if group_checkbox_detail['merge_field'].getparent():
                self.__fill_merge_field(
                    merge_field=group_checkbox_detail['merge_field'],
                    parent=group_checkbox_detail['merge_field'].getparent(),
                    text=''
                )

            # nếu value truyền lên ko có trong các value của checkbox thì bỏ qua
            if any([value not in group_checkbox_detail['values'] for value in values]):
                continue

            for checkbox_info in group_checkbox_detail['checkbox_infos']:
                if checkbox_info['value'] in values:
                    print("checkbox_info,atg", checkbox_info['checkbox_obj'].tag)
                    for element in checkbox_info['checkbox_obj'].iter():

                        if element.tag == f'{{{NAMESPACE_WORDPROCESSINGML}}}t':

                            element.text = CHECKBOX_CHECKED_TEXT

    def __merge_checkbox(self, field_name, values):
        for group_checkbox_detail in self.merge_field_name__list_group_checkbox_details[field_name]:
            if group_checkbox_detail['merge_field'].getparent():
                self.__fill_merge_field(
                    merge_field=group_checkbox_detail['merge_field'],
                    parent=group_checkbox_detail['merge_field'].getparent(),
                    text=''
                )

            # nếu value truyền lên ko có trong các value của checkbox thì bỏ qua
            if any([value not in group_checkbox_detail['values'] for value in values]):
                continue

            for checkbox_info in group_checkbox_detail['checkbox_infos']:
                if checkbox_info['value'] in values:
                    checkbox_info['checkbox_obj'].append(Element(f'{{{NAMESPACE_WORDPROCESSINGML}}}checked'))

    @staticmethod
    def __fill_merge_field(merge_field, parent, text):
        text = text or ''  # text might be None

        # preserve new lines in replacement text
        text_parts = str(text).split('\n')
        nodes = []

        for text_part in text_parts:
            text_node = Element(f'{{{NAMESPACE_WORDPROCESSINGML}}}t')
            text_node.text = text_part
            nodes.append(text_node)

            nodes.append(Element(f'{{{NAMESPACE_WORDPROCESSINGML}}}br'))

        nodes.pop()  # remove last br element

        for node in reversed(nodes):
            merge_field.addnext(node)

        parent.remove(merge_field)  # remove old merge field element due to it is replaced by new text in nodes

    def __enter__(self):
        return self

    def __exit__(self, exc_type, value, traceback):
        if self.zip is not None:
            try:
                self.zip.close()
            finally:
                self.zip = None
